#!/usr/bin/env python3
import sys, json, os
from jinja2 import Environment, FileSystemLoader

def render_jinja(template_name: str, context: dict, output_file: str):
    """Generic Jinja2 renderer."""
    templates_path = os.path.join(os.path.dirname(__file__), "templates")
    env = Environment(loader=FileSystemLoader(templates_path))
    template = env.get_template(template_name)
    html = template.render(context)
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[OK] Rendered {template_name} → {output_file}")

def render_preview(input_json: str, output_html: str):
    data = json.load(open(input_json))
    render_jinja("preview.html.j2", {"data": data}, output_html)

def render_consolidate(input_json: str, output_html: str):
    data = json.load(open(input_json))
    render_jinja("report.html.j2", {"data": data}, output_html)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: render_report.py [preview|consolidate] input.json output.html")
        sys.exit(1)

    mode, inp, out = sys.argv[1], sys.argv[2], sys.argv[3]
    if mode == "preview":
        render_preview(inp, out)
    elif mode == "consolidate":
        render_consolidate(inp, out)
    else:
        sys.exit("Invalid mode.")

#!/usr/bin/env bash
set -euo pipefail

LOG_FILE="deploy.log"
MAX_PARALLEL=${MAX_PARALLEL:-10}
mkdir -p artifacts

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log_info()  { echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE" >&2; }
log_success(){ echo -e "${GREEN}[OK]${NC} $1" | tee -a "$LOG_FILE"; }

trap 'log_error "Unexpected error on line $LINENO"; exit 1' ERR

validate_inputs() {
  log_info "Validating inputs..."
  if [[ -z "${APPLICATIONS:-}" && ! -f "app.properties" ]]; then
    log_error "APPLICATIONS variable or app.properties file required."
    exit 1
  fi
  if [[ "${ENVIRONMENT,,}" == "prod" && -z "${CHANGE_RECORD:-}" ]]; then
    log_error "CHANGE_RECORD is mandatory for PROD environment."
    exit 1
  fi
}

prepare_matrix() {
  validate_inputs
  log_info "Preparing deployment matrix..."
  local source_data="${APPLICATIONS:-$(cat app.properties)}"
  echo "{}" > matrix.json

  while IFS='=' read -r APP VERSION; do
    [[ -z "$APP" || -z "$VERSION" ]] && continue
    jq --arg app "$APP" --arg ver "$VERSION" '. + {($app): $ver}' matrix.json > tmp.$$.json && mv tmp.$$.json matrix.json
  done <<< "$source_data"

  local total_apps
  total_apps=$(jq 'keys | length' matrix.json)
  log_info "Matrix prepared for $total_apps applications."
  jq . matrix.json

  python3 scripts/render_report.py preview matrix.json preview.html
  log_success "Preview HTML generated: preview.html"
}

deploy_batch() {
  local batch_index=${1:-1}
  log_info "Running batch $batch_index"

  local all_apps=( $(jq -r 'keys[]' matrix.json) )
  local total=${#all_apps[@]}
  local start=$(( (batch_index - 1) * MAX_PARALLEL ))
  local end=$(( start + MAX_PARALLEL - 1 ))

  for i in $(seq $start $end); do
    [[ $i -ge $total ]] && break
    local APP="${all_apps[$i]}"
    local VERSION
    VERSION=$(jq -r --arg app "$APP" '.[$app]' matrix.json)
    deploy_app "$APP" "$VERSION" &
  done
  wait
  log_success "Batch $batch_index completed."
}

deploy_app() {
  local APP_NAME="$1"
  local VERSION="$2"
  local STATUS="SUCCESS"
  local ERRORS=""

  log_info "Deploying $APP_NAME:$VERSION"

  if ! helm upgrade --install "$APP_NAME" "$HELM_CHARTS_PATH/$APP_NAME" \
      --namespace "$HELM_NAMESPACE" \
      --create-namespace \
      --set image.tag="$VERSION" \
      --kube-context "$KUBE_CONTEXT" \
      > "${APP_NAME}.log" 2>&1; then
    STATUS="FAILED"
    ERRORS=$(grep -i "error" "${APP_NAME}.log" | head -5 | tr '\n' ' ')
  fi

  jq -n \
    --arg name "$APP_NAME" \
    --arg version "$VERSION" \
    --arg status "$STATUS" \
    --arg error "$ERRORS" \
    '{app_name:$name, version:$version, status:$status, error:$error}' \
    > "deploy-output-${APP_NAME}.json"

  log_info "$APP_NAME → $STATUS"
}

consolidate() {
  log_info "Consolidating deployment results..."
  jq -s '.' deploy-output-*.json > combined.json
  python3 scripts/render_report.py consolidate combined.json report.html
  log_success "Final report generated: report.html"
}

case "${1:-}" in
  prepare_matrix) prepare_matrix ;;
  deploy_batch) deploy_batch "$2" ;;
  consolidate) consolidate ;;
  *) log_error "Usage: $0 {prepare_matrix|deploy_batch <batch#>|consolidate}"; exit 1 ;;
esac
